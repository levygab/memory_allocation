int main(){
    return grozizi
}